export RELAY_KEY=236f27aa-74fb-4ee5-b97e-b6cdab289bbd
export RELAY_SECRET=fxsylP6iTc4X



relay login -k 236f27aa-74fb-4ee5-b97e-b6cdab289bbd -s fxsylP6iTc4X